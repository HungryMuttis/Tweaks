# Tweaks
- Upon player revival, gives set amount of oxygen
- Stops oxygen consumption if player is dead

## Almost not tested
I tested it with only me and myself (two instances of the game). But it *should* work with more players.

# Big thanks to
**me** for doing everything